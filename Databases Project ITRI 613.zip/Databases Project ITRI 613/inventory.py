import json
import random
import time
from datetime import datetime
from azure.eventhub import EventHubProducerClient, EventData

# Azure Event Hub connection settings
#CONNECTION_STR = 'Endpoint=sb://warehouse-streaming.servicebus.windows.net/;SharedAccessKeyName=inventory;SharedAccessKey=ol4vs/S9vcOO+jRV3tTY5rISv6xPqGrXV+AEhFBY+Xo=;EntityPath=inventory-events'
EVENTHUB_NAME = 'inventory-events'

# Sample items and categories
ITEMS = [
    {"item_id": "P001", "item_name": "Laptop", "category": "Electronics"},
    {"item_id": "P002", "item_name": "Desk Chair", "category": "Furniture"},
    {"item_id": "P003", "item_name": "Notebook", "category": "Stationery"},
    {"item_id": "P004", "item_name": "Coffee Machine", "category": "Appliances"},
    {"item_id": "P005", "item_name": "Smartphone", "category": "Electronics"},
    {"item_id": "P006", "item_name": "Monitor", "category": "Electronics"},
    {"item_id": "P007", "item_name": "Keyboard", "category": "Electronics"},
    {"item_id": "P008", "item_name": "Mouse", "category": "Electronics"},
    {"item_id": "P009", "item_name": "Desk Lamp", "category": "Furniture"},
    {"item_id": "P010", "item_name": "Bookshelf", "category": "Furniture"},
    {"item_id": "P011", "item_name": "Pen", "category": "Stationery"},
    {"item_id": "P012", "item_name": "Stapler", "category": "Stationery"},
    {"item_id": "P013", "item_name": "Toaster", "category": "Appliances"},
    {"item_id": "P014", "item_name": "Blender", "category": "Appliances"},
    {"item_id": "P015", "item_name": "Headphones", "category": "Electronics"},
    {"item_id": "P016", "item_name": "Tablet", "category": "Electronics"},
    {"item_id": "P017", "item_name": "Office Desk", "category": "Furniture"},
    {"item_id": "P018", "item_name": "Filing Cabinet", "category": "Furniture"},
    {"item_id": "P019", "item_name": "Highlighter", "category": "Stationery"},
    {"item_id": "P020", "item_name": "Scissors", "category": "Stationery"},
    {"item_id": "P021", "item_name": "Microwave", "category": "Appliances"},
    {"item_id": "P022", "item_name": "Electric Kettle", "category": "Appliances"},
    {"item_id": "P023", "item_name": "Printer", "category": "Electronics"},
    {"item_id": "P024", "item_name": "Webcam", "category": "Electronics"}
]

WAREHOUSES = ["New York", "Los Angeles", "Chicago", "Houston",
        "Phoenix", "Philadelphia", "Atlanta", "Denver"]
OPERATORS = ["Alice Pallet", "Bob Stacker", "Charlie Loader", "Diana Scanner",
        "Eve Packer", "Frank Dock", "Grace Label", "Hank Shipper",
        "Ivy Receiver", "Jack Inventory"]

def generate_inventory_data():
    item = random.choice(ITEMS)
    warehouse = random.choice(WAREHOUSES)
    operator = random.choice(OPERATORS)
    stock_count = random.randint(0, 50)
    low_stock_threshold = random.randint(5, 15)

    inventory_record = {
        "item_id": item["item_id"],
        "item_name": item["item_name"],
        "category": item["category"],
        "warehouse_id": warehouse,
        "stock_count": stock_count,
        "low_stock_threshold": low_stock_threshold,
        "timestamp": datetime.utcnow().isoformat(),
        "scan_operator": operator
    }

    return inventory_record

def send_inventory_data():
    producer = EventHubProducerClient.from_connection_string(conn_str=CONNECTION_STR, eventhub_name=EVENTHUB_NAME)
    while True:
        data = generate_inventory_data()
        event_data_batch = producer.create_batch(partition_key=data["warehouse_id"])
        event_data_batch.add(EventData(json.dumps(data)))
        producer.send_batch(event_data_batch)
        print(f"Sent inventory data: {data}")
        time.sleep(1)  # send every 5 seconds

if __name__ == "__main__":
    send_inventory_data()
