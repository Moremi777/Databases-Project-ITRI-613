import json
import random
import time
from datetime import datetime, timedelta
from azure.eventhub import EventHubProducerClient, EventData

# Azure Event Hub connection settings
#CONNECTION_STR = 'Endpoint=sb://warehouse-streaming.servicebus.windows.net/;SharedAccessKeyName=truck-gps;SharedAccessKey=PFAOZNUpiEZuYmKqThAnMkSH4jGv97DAx+AEhIrftLI=;EntityPath=truck-gps-events'
EVENTHUB_NAME = 'truck-gps-events'

TRUCKS = [f"TRUCK-{i:03d}" for i in range(1, 21)]  # TRUCK-001 to TRUCK-020
DRIVERS = [ "John McTire", "Sarah Diesel", "Mike Hauler", "Emma Overload", 
        "Alex Wheel", "Priya Cargo", "Jamal Road", "Luis Bigrig",
        "Charlie Gear", "Diana Axle", "Eve Longhaul", "Frank Tow",
        "Grace Flatbed", "Hank Semi", "Ivy Transport"]
WAREHOUSES = ["New York", "Los Angeles", "Chicago", "Houston",
        "Phoenix", "Philadelphia", "Atlanta", "Denver"]

def generate_truck_data():
    truck = random.choice(TRUCKS)
    driver = random.choice(DRIVERS)
    warehouse = random.choice(WAREHOUSES)

    latitude = random.uniform(-34.0, -33.0)  # Example range: near Cape Town
    longitude = random.uniform(18.0, 19.0)

    status = random.choice(["En Route", "Delayed", "Arrived"])
    cargo_items = random.sample(["P001", "P002", "P003", "P004", "P005"], random.randint(1, 3))
    est_arrival = (datetime.utcnow() + timedelta(minutes=random.randint(10, 60))).isoformat()

    truck_record = {
        "truck_id": truck,
        "driver_name": driver,
        "current_location_latitude": latitude,
        "current_location_longitude": longitude,
        "destination_warehouse_id": warehouse,
        "estimated_arrival_time": est_arrival,
        "cargo_items": cargo_items,
        "status": status,
        "timestamp": datetime.utcnow().isoformat()
    }

    return truck_record

def send_truck_data():
    producer = EventHubProducerClient.from_connection_string(conn_str=CONNECTION_STR, eventhub_name=EVENTHUB_NAME)
    while True:
        data = generate_truck_data()
        event_data_batch = producer.create_batch(partition_key=data["destination_warehouse_id"])
        event_data_batch.add(EventData(json.dumps(data)))
        producer.send_batch(event_data_batch)
        print(f"Sent truck GPS data: {data}")
        time.sleep(1)  # send every 7 seconds

if __name__ == "__main__":
    send_truck_data()
